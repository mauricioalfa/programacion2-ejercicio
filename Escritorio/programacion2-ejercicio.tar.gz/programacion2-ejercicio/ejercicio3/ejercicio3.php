<?php
//mauricio enrique alfaro ramirez ar01132938
$radio=readline("Ingrese el radio del circulo : ");


$perimetro=2*pi()*$radio;
$area=pi()*pow($radio,2);

echo "El perimetro del circulo es: ".$perimetro."\n";
echo "El area del circulo es: ".$area."\n";


?>
