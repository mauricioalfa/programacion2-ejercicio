<?php 
//mauricio enrique alfaro ramirez ar01132938
$numero=readline("Digite un numero de tres cifras : ");
$invertido=0;
while ($numero>0) { 
		$digito = $numero%10; 
		$numero = $numero-$digito;
		$numero = $numero/10;
		$invertido = $invertido*10+$digito;
	}
	echo 'El numero ivertido es: ',$invertido;

?>
