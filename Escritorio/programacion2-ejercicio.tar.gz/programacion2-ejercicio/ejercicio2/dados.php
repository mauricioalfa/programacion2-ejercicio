<?php

//mauricio enrique alfaro ramirez ar01132938
	for ($i=1; $i <=6 ; $i++) {

			echo "";

	for ($j=1; $j<=6 ; $j++) {

	echo $i.$j."\n ";
	echo "\n";

	}
}

 ?>
