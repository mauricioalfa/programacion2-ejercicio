<?php
//mauricio enrique alfaro ar01132938
$n=readline("n: ");
$i=1.0;
$pi=0.0;
while($i<$n){
	$pi=$pi+$i*$i;
	$i=$i++;
	}
echo $pi;
?>
